<?php
namespace MSP\TwoFactorAuth\Api\Data;

/**
 * Extension class for @see \MSP\TwoFactorAuth\Api\Data\UserConfigInterface
 */
class UserConfigExtension extends \Magento\Framework\Api\AbstractSimpleObject implements UserConfigExtensionInterface
{
}
