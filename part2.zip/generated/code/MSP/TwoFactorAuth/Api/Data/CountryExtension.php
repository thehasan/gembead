<?php
namespace MSP\TwoFactorAuth\Api\Data;

/**
 * Extension class for @see \MSP\TwoFactorAuth\Api\Data\CountryInterface
 */
class CountryExtension extends \Magento\Framework\Api\AbstractSimpleObject implements CountryExtensionInterface
{
}
