<?php
namespace MSP\TwoFactorAuth\Api\Data;

/**
 * ExtensionInterface class for @see \MSP\TwoFactorAuth\Api\Data\UserConfigInterface
 */
interface UserConfigExtensionInterface extends \Magento\Framework\Api\ExtensionAttributesInterface
{
}
