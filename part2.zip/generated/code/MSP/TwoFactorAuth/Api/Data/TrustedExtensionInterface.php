<?php
namespace MSP\TwoFactorAuth\Api\Data;

/**
 * ExtensionInterface class for @see \MSP\TwoFactorAuth\Api\Data\TrustedInterface
 */
interface TrustedExtensionInterface extends \Magento\Framework\Api\ExtensionAttributesInterface
{
}
