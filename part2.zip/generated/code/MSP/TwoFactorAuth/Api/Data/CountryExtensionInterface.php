<?php
namespace MSP\TwoFactorAuth\Api\Data;

/**
 * ExtensionInterface class for @see \MSP\TwoFactorAuth\Api\Data\CountryInterface
 */
interface CountryExtensionInterface extends \Magento\Framework\Api\ExtensionAttributesInterface
{
}
