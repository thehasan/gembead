<?php
namespace Zemez\ThemeOptions\Helper\Data;

/**
 * Interceptor class for @see \Zemez\ThemeOptions\Helper\Data
 */
class Interceptor extends \Zemez\ThemeOptions\Helper\Data implements \Magento\Framework\Interception\InterceptorInterface
{
    use \Magento\Framework\Interception\Interceptor;

    public function __construct(\Zemez\ThemeOptions\Helper\ColorScheme $colorScheme, \Magento\Framework\App\Helper\Context $context, \Magento\Framework\Serialize\Serializer\Json $serialize, \Magento\Framework\ObjectManagerInterface $objectManager)
    {
        $this->___init();
        parent::__construct($colorScheme, $context, $serialize, $objectManager);
    }

    /**
     * {@inheritdoc}
     */
    public function getCurrentColorScheme($store = null)
    {
        $pluginInfo = $this->pluginList->getNext($this->subjectType, 'getCurrentColorScheme');
        if (!$pluginInfo) {
            return parent::getCurrentColorScheme($store);
        } else {
            return $this->___callPlugins('getCurrentColorScheme', func_get_args(), $pluginInfo);
        }
    }
}
