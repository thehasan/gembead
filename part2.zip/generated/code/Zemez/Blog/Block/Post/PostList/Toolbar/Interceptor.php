<?php
namespace Zemez\Blog\Block\Post\PostList\Toolbar;

/**
 * Interceptor class for @see \Zemez\Blog\Block\Post\PostList\Toolbar
 */
class Interceptor extends \Zemez\Blog\Block\Post\PostList\Toolbar implements \Magento\Framework\Interception\InterceptorInterface
{
    use \Magento\Framework\Interception\Interceptor;

    public function __construct(\Magento\Framework\View\Element\Template\Context $context, \Magento\Framework\Session\SessionManager $sessionsManager, \Zemez\Blog\Model\PostList\Toolbar $toolbarModel, \Zemez\Blog\Model\ResourceModel\Post\Collection $postCollection, \Zemez\Blog\Helper\Data $helper, \Magento\Framework\Registry $registry, array $data = [])
    {
        $this->___init();
        parent::__construct($context, $sessionsManager, $toolbarModel, $postCollection, $helper, $registry, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function getWidgetOptionsJson(array $customOptions = [])
    {
        $pluginInfo = $this->pluginList->getNext($this->subjectType, 'getWidgetOptionsJson');
        if (!$pluginInfo) {
            return parent::getWidgetOptionsJson($customOptions);
        } else {
            return $this->___callPlugins('getWidgetOptionsJson', func_get_args(), $pluginInfo);
        }
    }
}
