<?php
namespace Zemez\SocialLogin\Controller\Login\Grant;

/**
 * Interceptor class for @see \Zemez\SocialLogin\Controller\Login\Grant
 */
class Interceptor extends \Zemez\SocialLogin\Controller\Login\Grant implements \Magento\Framework\Interception\InterceptorInterface
{
    use \Magento\Framework\Interception\Interceptor;

    public function __construct(\Zemez\SocialLogin\Model\ResourceModel\Provider\Collection $collection, \Zemez\SocialLogin\Helper\Data $socialLoginHelper, \Zemez\SocialLogin\Model\AccountManagement $accountManagement, \Magento\Customer\Model\Session $customerSession, \Magento\Framework\App\Action\Context $context)
    {
        $this->___init();
        parent::__construct($collection, $socialLoginHelper, $accountManagement, $customerSession, $context);
    }

    /**
     * {@inheritdoc}
     */
    public function dispatch(\Magento\Framework\App\RequestInterface $request)
    {
        $pluginInfo = $this->pluginList->getNext($this->subjectType, 'dispatch');
        if (!$pluginInfo) {
            return parent::dispatch($request);
        } else {
            return $this->___callPlugins('dispatch', func_get_args(), $pluginInfo);
        }
    }
}
